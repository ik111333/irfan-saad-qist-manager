عرفان اینڈ سعد قسط مینیجر — اینڈرائیڈ پروجیکٹ

اہم بات: یہ ابھی APK فائل نہیں ہے؛ یہ Android Studio میں APK بنانے کے لیے پروجیکٹ ہے۔ اس ماحول میں Android SDK/Gradle نصب نہیں، اس لیے یہاں سے APK کمپائل نہیں ہو سکی۔

APK بنانے کا طریقہ:
1) کمپیوٹر پر Android Studio نصب کریں۔
2) اس ZIP کو Extract کریں۔
3) Android Studio میں اس فولڈر IrfanSaadQistManager کو Open کریں۔
4) Gradle sync مکمل ہونے دیں اور Android SDK 35 نصب ہونے دیں۔
5) Build > Build Bundle(s) / APK(s) > Build APK(s) منتخب کریں۔
6) بننے والی APK عموماً app/build/outputs/apk/debug/app-debug.apk میں ہوگی۔

یہ ورژن پہلے بنائے گئے HTML ڈیمو کو ایپ کے اندر چلاتا ہے۔ اس میں کسٹمر اندراج، تلاش، ادائیگی درج کرنا اور JSON بیک اپ/بحالی کی بنیادی سہولت ہے۔ ابھی تصاویر، مکمل قسط وار شیڈول، رسید کی پرنٹنگ، خرید/اسٹاک، اور تفصیلی منافع رپورٹس شامل نہیں ہیں۔

ڈیٹا فون کی ایپ کے اندر محفوظ ہوتا ہے۔ ایپ حذف کرنے سے پہلے بیک اپ Export ضرور کریں۔ APK اپڈیٹ کرتے وقت اسی applicationId اور مناسب signing key کی ضرورت ہوتی ہے۔

موبائل سے APK بنوانے کا اضافی طریقہ (کمپیوٹر کے بغیر، مگر GitHub اکاؤنٹ درکار ہے):
1) GitHub پر نیا repository بنائیں اور اس ZIP کے اندر موجود فائلیں upload کریں (ZIP فائل خود upload نہ کریں؛ پہلے extract کریں)۔
2) repository میں Actions کھولیں۔
3) “Build Android APK” workflow منتخب کریں اور “Run workflow” دبائیں، یا main branch میں فائلیں upload کرنے کے بعد build خود چلنے دیں۔
4) مکمل ہونے پر workflow کے صفحے کے نیچے Artifacts میں “irfan-saad-qist-manager-apk” ڈاؤن لوڈ کریں۔ ZIP artifact کھولنے پر app-debug.apk ملے گی۔
5) APK فون میں کھول کر install کریں۔ فون پوچھے تو اسی فائل مینیجر/براؤزر کو “Install unknown apps” کی اجازت دیں۔ صرف اپنی بنائی ہوئی APK نصب کریں۔

یہ workflow APK بنانے کی کوشش خودکار کرتا ہے، لیکن میں اس ماحول میں اسے چلا کر APK کی کامیابی کی تصدیق نہیں کر سکا۔
