plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

android {
    namespace = "pk.irfansaad.qistmanager"
    compileSdk = 35

    defaultConfig {
        applicationId = "pk.irfansaad.qistmanager"
        minSdk = 23
        targetSdk = 35
        versionCode = 1
        versionName = "1.0"
    }
}
